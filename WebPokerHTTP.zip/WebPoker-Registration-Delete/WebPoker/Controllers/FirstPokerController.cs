﻿using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebPoker.DataBaseContext;
using WebPoker.Models;
using WebPoker.PostRecord;
using Microsoft.AspNetCore.Identity;
namespace WebPoker.Controllers
{
    [Route("api/player")]
    [ApiController]
    public class FirstPokerController : ControllerBase
    {
        public FirstPokerController(PokerDbContext context)
        {
            _context = context;
        }
        private readonly PokerDbContext? _context;
        [HttpGet]
        public async Task<IActionResult> GetPlayers()
        {
            var player = await _context.Players
                .Select(player => new { player.Id, player.Nickname, player.Balance })
                .ToListAsync();
            return Ok(player);
        }

        [HttpPost]
        public async Task<IActionResult> CreatePlayer([FromBody] Request request)
        {
            if (string.IsNullOrWhiteSpace(request.Nickname) || string.IsNullOrWhiteSpace(request.Password))
                return BadRequest("Invalid Nickname or Password");
            var player = new Player()
            {
                Nickname = request.Nickname.Trim()
            };

            var hasher = new PasswordHasher<Player>();
            player.Password = hasher.HashPassword(player, request.Password);
            _context.Players.Add(player);
            await _context.SaveChangesAsync();
            return StatusCode(StatusCodes.Status201Created, new
            {
                player.Id,
                player.Nickname,
                player.Balance
            });
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeletePlayer(int Id)
        {
            var player = await _context.Players.FindAsync(Id);
            if (player == null)
                return NotFound();

            _context.Players.Remove(player);
            await _context.SaveChangesAsync();

            return NoContent();
        }

    }
}